module corelet (clk, reset, inst, data_in, ofifo_out, ofifo_valid, pmem_in, sfp_out);
  parameter bw = 4; parameter psum_bw = 16; parameter col = 8; parameter row = 8;
  input clk, reset; input [33:0] inst; input [row*bw-1:0] data_in;
  output [psum_bw*col-1:0] ofifo_out; output ofifo_valid;
  input [psum_bw*col-1:0] pmem_in; output [psum_bw*col-1:0] sfp_out;
  wire [row*bw-1:0] l0_out; wire l0_full, l0_ready;
  wire [psum_bw*col-1:0] array_out; wire [col-1:0] array_valid;
  wire ofifo_full, ofifo_ready;
  l0 #(.row(row), .bw(bw)) l0_inst (.clk(clk), .reset(reset), .in(data_in), .out(l0_out), .rd(inst[3]), .wr(inst[2]), .o_full(l0_full), .o_ready(l0_ready));
  mac_array #(.bw(bw), .psum_bw(psum_bw), .col(col), .row(row)) mac_array_inst (.clk(clk), .reset(reset), .out_s(array_out), .in_w(l0_out), .in_n({psum_bw*col{1'b0}}), .inst_w(inst[1:0]), .valid(array_valid));
  ofifo #(.col(col), .bw(psum_bw)) ofifo_inst (.clk(clk), .reset(reset), .in(array_out), .out(ofifo_out), .rd(inst[6]), .wr(array_valid), .o_full(ofifo_full), .o_ready(ofifo_ready), .o_valid(ofifo_valid));
  sfu #(.col(col), .psum_bw(psum_bw)) sfu_inst (.clk(clk), .reset(reset), .acc(inst[33]), .in(pmem_in), .out(sfp_out));
endmodule
