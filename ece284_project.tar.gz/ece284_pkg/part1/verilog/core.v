module core (clk, inst, ofifo_valid, D_xmem, sfp_out, reset);
  parameter bw = 4; parameter psum_bw = 16; parameter col = 8; parameter row = 8;
  input clk, reset; input [33:0] inst; input [bw*row-1:0] D_xmem;
  output ofifo_valid; output [psum_bw*col-1:0] sfp_out;
  wire [bw*row-1:0] xmem_q; wire [psum_bw*col-1:0] pmem_q, ofifo_out;
  sram_32b_w2048 xmem (.CLK(clk), .D(D_xmem), .Q(xmem_q), .CEN(inst[19]), .WEN(inst[18]), .A(inst[17:7]));
  sram_128b_w2048 pmem (.CLK(clk), .D(ofifo_out), .Q(pmem_q), .CEN(inst[32]), .WEN(inst[31]), .A(inst[30:20]));
  corelet #(.bw(bw), .psum_bw(psum_bw), .col(col), .row(row)) corelet_inst (.clk(clk), .reset(reset), .inst(inst), .data_in(xmem_q), .ofifo_out(ofifo_out), .ofifo_valid(ofifo_valid), .pmem_in(pmem_q), .sfp_out(sfp_out));
endmodule
