// mac.v : out = c + a*b
//   mode = 0 : a is UNSIGNED 4-bit (activation nibble, 0..15)   -> Part 1 and the X0 passes
//   mode = 1 : a is SIGNED   4-bit (delta dX, -8..7)            -> Part 2 delta passes
module mac (out, a, b, c, mode);

parameter bw = 4;
parameter psum_bw = 16;

output signed [psum_bw-1:0] out;
input         [bw-1:0] a;      // activation
input  signed [bw-1:0] b;      // weight (always signed)
input  signed [psum_bw-1:0] c;
input         mode;

wire signed [bw:0]     a_pad;
wire signed [2*bw:0]   product;

assign a_pad   = {mode & a[bw-1], a};   // mode 0: zero-extend, mode 1: sign-extend
assign product = a_pad * b;
assign out     = product + c;

endmodule
