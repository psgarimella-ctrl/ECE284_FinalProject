// corelet.v (Part 2 version) : L0 + mac_array + OFIFO + SFU
// inst bits:  [0] load  [1] execute  [2] l0_wr  [3] l0_rd  [6] ofifo_rd  [33] acc
//   new:      [34] mode (1 = signed activations)  [35] sfu shift (x16)
//             [36] save_y0  [37] load_y0  [38] relu_en
module corelet (clk, reset, inst, data_in, ofifo_out, ofifo_valid, pmem_in, sfp_out);

  parameter bw = 4;
  parameter psum_bw = 16;
  parameter acc_bw = 24;
  parameter col = 8;
  parameter row = 8;

  input  clk, reset;
  input  [38:0] inst;
  input  [row*bw-1:0] data_in;
  output [psum_bw*col-1:0] ofifo_out;
  output ofifo_valid;
  input  [psum_bw*col-1:0] pmem_in;
  output [acc_bw*col-1:0] sfp_out;

  wire [row*bw-1:0]      l0_out;
  wire                   l0_full, l0_ready;
  wire [psum_bw*col-1:0] array_out;
  wire [col-1:0]         array_valid;
  wire                   ofifo_full, ofifo_ready;

  l0 #(.row(row), .bw(bw)) l0_inst (
      .clk(clk), .reset(reset), .in(data_in), .out(l0_out),
      .wr(inst[2]), .rd(inst[3]), .o_full(l0_full), .o_ready(l0_ready));

  mac_array #(.bw(bw), .psum_bw(psum_bw), .col(col), .row(row)) mac_array_inst (
      .clk(clk), .reset(reset), .in_w(l0_out), .in_n({psum_bw*col{1'b0}}),
      .inst_w(inst[1:0]), .out_s(array_out), .valid(array_valid), .mode(inst[34]));

  ofifo #(.col(col), .bw(psum_bw)) ofifo_inst (
      .clk(clk), .reset(reset), .in(array_out), .wr(array_valid), .rd(inst[6]),
      .out(ofifo_out), .o_valid(ofifo_valid), .o_full(ofifo_full), .o_ready(ofifo_ready));

  sfu #(.col(col), .psum_bw(psum_bw), .acc_bw(acc_bw)) sfu_inst (
      .clk(clk), .reset(reset), .acc(inst[33]), .shift(inst[35]),
      .save_y0(inst[36]), .load_y0(inst[37]), .relu_en(inst[38]),
      .in(pmem_in), .out(sfp_out));

endmodule
