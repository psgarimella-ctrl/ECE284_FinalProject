// sfu.v (Part 2 version) : Special Function Unit
//   reset   : acc = 0
//   load_y0 : acc = saved Y0                 (start a delta frame from Y0)
//   acc     : acc = acc + in                 (or acc + 16*in when shift=1, for the X0_high pass)
//   save_y0 : y0  = acc                      (keep Y0 for reuse by the delta frames)
//   relu_en : out = ReLU(acc), otherwise out = acc (raw conv output, used in Part 2)
module sfu (clk, reset, acc, shift, save_y0, load_y0, relu_en, in, out);

  parameter col     = 8;
  parameter psum_bw = 16;     // width of one psum from pmem
  parameter acc_bw  = 24;     // accumulator width (Y0 over 9 kij needs >= 19 bits)

  input  clk, reset;
  input  acc, shift, save_y0, load_y0, relu_en;
  input  [psum_bw*col-1:0] in;
  output [acc_bw*col-1:0]  out;

  genvar i;
  for (i=0; i<col; i=i+1) begin : col_num

      reg  signed [acc_bw-1:0]  acc_q;     // running sum
      reg  signed [acc_bw-1:0]  y0_q;      // stored Y0 for this column
      wire signed [psum_bw-1:0] in_col;
      wire signed [acc_bw-1:0]  in_ext;

      assign in_col = in[psum_bw*(i+1)-1 : psum_bw*i];
      assign in_ext = shift ? ($signed(in_col) <<< 4) : $signed(in_col);   // sign-extended to acc_bw

      always @ (posedge clk) begin
         if (reset)        acc_q <= 0;
         else if (load_y0) acc_q <= y0_q;
         else if (acc)     acc_q <= acc_q + in_ext;

         if (reset)        y0_q  <= 0;
         else if (save_y0) y0_q  <= acc_q;
      end

      assign out[acc_bw*(i+1)-1 : acc_bw*i] = (relu_en && acc_q[acc_bw-1]) ? {acc_bw{1'b0}} : acc_q;
  end

endmodule
