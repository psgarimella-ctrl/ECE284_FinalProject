// core_tb.v (Part 2) : differential video-frame processing
// Based on the course core_tb.v. Weights are loaded ONCE per kij and reused for 5 passes:
//   pass 0: X0_high (unsigned)   pass 1: X0_low (unsigned)
//   pass 2..4: dX1..dX3 (signed, mode=1)
// Then, per output pixel:  Y0 = 16*sum(high psums) + sum(low psums)   -> stored in SFU
//                          Yi = Y0 + sum(dXi psums)                    -> i = 1..3
`timescale 1ns/1ps

module core_tb;

parameter bw = 4;
parameter psum_bw = 16;
parameter acc_bw = 24;
parameter len_kij = 9;
parameter len_onij = 16;
parameter col = 8;
parameter row = 8;
parameter len_nij = 36;
parameter n_pass = 5;                 // X0_high, X0_low, dX1, dX2, dX3

reg clk = 0;
reg reset = 1;

wire [38:0] inst_q;

reg [bw*row-1:0] D_xmem_q = 0;
reg CEN_xmem = 1, WEN_xmem = 1;  reg [10:0] A_xmem = 0;
reg CEN_xmem_q = 1, WEN_xmem_q = 1; reg [10:0] A_xmem_q = 0;
reg CEN_pmem = 1, WEN_pmem = 1;  reg [10:0] A_pmem = 0;
reg CEN_pmem_q = 1, WEN_pmem_q = 1; reg [10:0] A_pmem_q = 0;
reg ofifo_rd_q = 0, l0_rd_q = 0, l0_wr_q = 0, execute_q = 0, load_q = 0, acc_q = 0;
reg mode_q = 0, shift_q = 0, save_q = 0, loady0_q = 0, relu_q = 0;

reg [bw*row-1:0] D_xmem;
reg ofifo_rd, l0_rd, l0_wr, execute, load, acc;
reg mode, shift, save_y0, load_y0, relu_en;

reg [acc_bw*col-1:0] answer;
reg [8*30:1] w_file_name;
reg [8*30:1] x_file_name;
reg [8*30:1] y_file_name;
wire ofifo_valid;
wire [acc_bw*col-1:0] sfp_out;

integer x_file, x_scan_file;
integer w_file, w_scan_file;
integer acc_file, acc_scan_file;
integer y_file [0:3];
integer y_scan_file;
integer captured_data;
integer t, i, j, k, kij, p, f, o;
integer error, n_checked;
reg [10:0] base_addr [0:len_kij-1];   // pmem addresses (pass 0) for one output pixel

// cycle counters
integer cycle = 0;
integer c_start, c_end, c_pass_start, c_pass_total, c_load_total;

assign inst_q[38]    = relu_q;
assign inst_q[37]    = loady0_q;
assign inst_q[36]    = save_q;
assign inst_q[35]    = shift_q;
assign inst_q[34]    = mode_q;
assign inst_q[33]    = acc_q;
assign inst_q[32]    = CEN_pmem_q;
assign inst_q[31]    = WEN_pmem_q;
assign inst_q[30:20] = A_pmem_q;
assign inst_q[19]    = CEN_xmem_q;
assign inst_q[18]    = WEN_xmem_q;
assign inst_q[17:7]  = A_xmem_q;
assign inst_q[6]     = ofifo_rd_q;
assign inst_q[5]     = 1'b0;
assign inst_q[4]     = 1'b0;
assign inst_q[3]     = l0_rd_q;
assign inst_q[2]     = l0_wr_q;
assign inst_q[1]     = execute_q;
assign inst_q[0]     = load_q;

core #(.bw(bw), .psum_bw(psum_bw), .acc_bw(acc_bw), .col(col), .row(row)) core_instance (
  .clk(clk), .inst(inst_q), .ofifo_valid(ofifo_valid),
  .D_xmem(D_xmem_q), .sfp_out(sfp_out), .reset(reset));

always @ (posedge clk) cycle = cycle + 1;

initial begin
  D_xmem = 0; CEN_xmem = 1; WEN_xmem = 1; A_xmem = 0;
  ofifo_rd = 0; l0_rd = 0; l0_wr = 0; execute = 0; load = 0; acc = 0;
  mode = 0; shift = 0; save_y0 = 0; load_y0 = 0; relu_en = 0;
  c_pass_total = 0; c_load_total = 0;

  $dumpfile("core_tb.vcd");
  $dumpvars(0, core_tb);

  //////// Reset ////////
  #0.5 clk = 1'b0;  reset = 1;
  #0.5 clk = 1'b1;
  for (i=0; i<10; i=i+1) begin #0.5 clk = 1'b0; #0.5 clk = 1'b1; end
  #0.5 clk = 1'b0;  reset = 0;
  #0.5 clk = 1'b1;
  #0.5 clk = 1'b0;
  #0.5 clk = 1'b1;

  //////// Write the 5 activation sets to xmem: pass p at addresses p*36 .. p*36+35 ////////
  for (p=0; p<n_pass; p=p+1) begin
    case (p)
      0: x_file_name = "act_x0_high.txt";
      1: x_file_name = "act_x0_low.txt";
      2: x_file_name = "act_dx1.txt";
      3: x_file_name = "act_dx2.txt";
      4: x_file_name = "act_dx3.txt";
    endcase
    x_file = $fopen(x_file_name, "r");
    x_scan_file = $fscanf(x_file, "%s", captured_data);
    x_scan_file = $fscanf(x_file, "%s", captured_data);
    x_scan_file = $fscanf(x_file, "%s", captured_data);
    A_xmem = p*len_nij;
    for (t=0; t<len_nij; t=t+1) begin
      #0.5 clk = 1'b0;  x_scan_file = $fscanf(x_file, "%32b", D_xmem); WEN_xmem = 0; CEN_xmem = 0; if (t>0) A_xmem = A_xmem + 1;
      #0.5 clk = 1'b1;
    end
    #0.5 clk = 1'b0;  WEN_xmem = 1; CEN_xmem = 1; A_xmem = 0;
    #0.5 clk = 1'b1;
    $fclose(x_file);
  end

  c_start = cycle;

  for (kij=0; kij<len_kij; kij=kij+1) begin  // kij loop

    case (kij)
     0: w_file_name = "weight_itile0_otile0_kij0.txt";
     1: w_file_name = "weight_itile0_otile0_kij1.txt";
     2: w_file_name = "weight_itile0_otile0_kij2.txt";
     3: w_file_name = "weight_itile0_otile0_kij3.txt";
     4: w_file_name = "weight_itile0_otile0_kij4.txt";
     5: w_file_name = "weight_itile0_otile0_kij5.txt";
     6: w_file_name = "weight_itile0_otile0_kij6.txt";
     7: w_file_name = "weight_itile0_otile0_kij7.txt";
     8: w_file_name = "weight_itile0_otile0_kij8.txt";
    endcase
    w_file = $fopen(w_file_name, "r");
    w_scan_file = $fscanf(w_file, "%s", captured_data);
    w_scan_file = $fscanf(w_file, "%s", captured_data);
    w_scan_file = $fscanf(w_file, "%s", captured_data);

    c_pass_start = cycle;

    // reset clears the old weights (load_ready) before loading this kij's weights
    #0.5 clk = 1'b0;  reset = 1;
    #0.5 clk = 1'b1;
    #0.5 clk = 1'b0;  reset = 0;
    #0.5 clk = 1'b1;

    /////// Kernel data writing to memory ///////
    A_xmem = 11'b10000000000;
    for (t=0; t<col; t=t+1) begin
      #0.5 clk = 1'b0;  w_scan_file = $fscanf(w_file, "%32b", D_xmem); WEN_xmem = 0; CEN_xmem = 0; if (t>0) A_xmem = A_xmem + 1;
      #0.5 clk = 1'b1;
    end
    #0.5 clk = 1'b0;  WEN_xmem = 1; CEN_xmem = 1; A_xmem = 0;
    #0.5 clk = 1'b1;
    $fclose(w_file);

    /////// Kernel data writing to L0 ///////
    A_xmem = 11'b10000000000;
    for (t=0; t<col+1; t=t+1) begin
      #0.5 clk = 1'b0;
        if (t<col) begin CEN_xmem = 0; WEN_xmem = 1; if (t>0) A_xmem = A_xmem + 1; end
        else       begin CEN_xmem = 1; WEN_xmem = 1; end
        if (t>0) l0_wr = 1;
      #0.5 clk = 1'b1;
    end
    #0.5 clk = 1'b0;  l0_wr = 0; CEN_xmem = 1; A_xmem = 0;
    #0.5 clk = 1'b1;

    /////// Kernel loading to PEs (ONCE per kij) ///////
    for (t=0; t<col; t=t+1) begin
      #0.5 clk = 1'b0;  l0_rd = 1; load = 1;
      #0.5 clk = 1'b1;
    end
    #0.5 clk = 1'b0;  load = 0; l0_rd = 0;
    #0.5 clk = 1'b1;
    for (i=0; i<row+col; i=i+1) begin #0.5 clk = 1'b0; #0.5 clk = 1'b1; end

    c_load_total = c_load_total + (cycle - c_pass_start);

    /////// 5 passes with the SAME weights ///////
    for (p=0; p<n_pass; p=p+1) begin
      c_pass_start = cycle;

      // Activation data writing to L0 (from xmem region p)
      A_xmem = p*len_nij;
      for (t=0; t<len_nij+1; t=t+1) begin
        #0.5 clk = 1'b0;
          if (t<len_nij) begin CEN_xmem = 0; WEN_xmem = 1; if (t>0) A_xmem = A_xmem + 1; end
          else           begin CEN_xmem = 1; WEN_xmem = 1; end
          if (t>0) l0_wr = 1;
        #0.5 clk = 1'b1;
      end
      #0.5 clk = 1'b0;  l0_wr = 0; CEN_xmem = 1; A_xmem = 0;
      #0.5 clk = 1'b1;

      // Execution: unsigned for X0 nibbles, signed for deltas
      for (t=0; t<len_nij; t=t+1) begin
        #0.5 clk = 1'b0;  l0_rd = 1; execute = 1; mode = (p >= 2);
        #0.5 clk = 1'b1;
      end
      #0.5 clk = 1'b0;  l0_rd = 0; execute = 0;
      #0.5 clk = 1'b1;
      for (i=0; i<row+col+10; i=i+1) begin #0.5 clk = 1'b0; #0.5 clk = 1'b1; end
      #0.5 clk = 1'b0;  mode = 0;
      #0.5 clk = 1'b1;

      // OFIFO -> pmem at ((p*9 + kij)*36 + nij)
      A_pmem = (p*len_kij + kij)*len_nij;
      for (t=0; t<len_nij; t=t+1) begin
        #0.5 clk = 1'b0;  ofifo_rd = 1; CEN_pmem = 0; WEN_pmem = 0; if (t>0) A_pmem = A_pmem + 1;
        #0.5 clk = 1'b1;
      end
      #0.5 clk = 1'b0;  ofifo_rd = 0; CEN_pmem = 1; WEN_pmem = 1; A_pmem = 0;
      #0.5 clk = 1'b1;

      c_pass_total = c_pass_total + (cycle - c_pass_start);
    end
  end  // kij loop

  c_end = cycle;

  ////////// Accumulation + reconstruction //////////
  acc_file = $fopen("acc_address.txt", "r");
  acc_scan_file = $fscanf(acc_file, "%s", captured_data);
  acc_scan_file = $fscanf(acc_file, "%s", captured_data);
  acc_scan_file = $fscanf(acc_file, "%s", captured_data);

  for (f=0; f<4; f=f+1) begin
    case (f)
      0: y_file_name = "out_y0.txt";
      1: y_file_name = "out_y1.txt";
      2: y_file_name = "out_y2.txt";
      3: y_file_name = "out_y3.txt";
    endcase
    y_file[f] = $fopen(y_file_name, "r");
    y_scan_file = $fscanf(y_file[f], "%s", captured_data);
    y_scan_file = $fscanf(y_file[f], "%s", captured_data);
    y_scan_file = $fscanf(y_file[f], "%s", captured_data);
  end

  error = 0; n_checked = 0;
  $display("############ Verification Start (Part 2) #############");

  for (o=0; o<len_onij; o=o+1) begin
    // 9 pmem addresses of this output pixel (pass-0 region)
    for (k=0; k<len_kij; k=k+1) acc_scan_file = $fscanf(acc_file, "%11b", base_addr[k]);

    for (f=0; f<4; f=f+1) begin
      // start value: 0 for Y0, stored Y0 for the delta frames
      #0.5 clk = 1'b0;  if (f==0) reset = 1; else load_y0 = 1;
      #0.5 clk = 1'b1;
      #0.5 clk = 1'b0;  reset = 0; load_y0 = 0;
      #0.5 clk = 1'b1;

      if (f==0) begin
        // Y0 = 16*(high psums) + (low psums): 18 reads, the first 9 shifted
        for (j=0; j<2*len_kij+1; j=j+1) begin
          #0.5 clk = 1'b0;
            if (j<2*len_kij) begin
              CEN_pmem = 0; WEN_pmem = 1;
              A_pmem = base_addr[j % len_kij] + (j / len_kij)*len_kij*len_nij;
            end else begin CEN_pmem = 1; WEN_pmem = 1; end
            if (j>0) begin acc = 1; shift = (j <= len_kij); end
          #0.5 clk = 1'b1;
        end
      end else begin
        // Yf = Y0 + (dXf psums): 9 reads from pass f+1
        for (j=0; j<len_kij+1; j=j+1) begin
          #0.5 clk = 1'b0;
            if (j<len_kij) begin
              CEN_pmem = 0; WEN_pmem = 1;
              A_pmem = base_addr[j] + (f+1)*len_kij*len_nij;
            end else begin CEN_pmem = 1; WEN_pmem = 1; end
            if (j>0) begin acc = 1; shift = 0; end
          #0.5 clk = 1'b1;
        end
      end
      #0.5 clk = 1'b0;  acc = 0; shift = 0; if (f==0) save_y0 = 1;
      #0.5 clk = 1'b1;
      #0.5 clk = 1'b0;  save_y0 = 0;
      #0.5 clk = 1'b1;
      #0.5 clk = 1'b0;
      #0.5 clk = 1'b1;

      y_scan_file = $fscanf(y_file[f], "%192b", answer);
      n_checked = n_checked + 1;
      if (sfp_out == answer)
        $display("pixel %2d  Y%0d matched", o, f);
      else begin
        $display("pixel %2d  Y%0d ERROR", o, f);
        $display("  sfpout: %h", sfp_out);
        $display("  answer: %h", answer);
        error = error + 1;
      end
    end
  end

  if (error == 0) $display("############ No error detected (%0d outputs checked) ##############", n_checked);
  else            $display("############ %0d errors out of %0d ##############", error, n_checked);

  $display("---------------- Cycle report ----------------");
  $display("Total compute cycles (9 kij, weight loads + passes): %0d", c_end - c_start);
  $display("  weight loading (9 x once)                        : %0d", c_load_total);
  $display("  activation passes (9 kij x %0d passes)            : %0d", n_pass, c_pass_total);
  $display("  cycles per pass                                  : %0d", c_pass_total/(len_kij*n_pass));
  $display("Conventional (8 passes/kij) estimate               : %0d", c_load_total + (c_pass_total/(len_kij*n_pass))*len_kij*8);
  $display("Pass reduction: 8 / %0d = %0.2fx", n_pass, 8.0/n_pass);

  $fclose(acc_file);
  for (t=0; t<10; t=t+1) begin #0.5 clk = 1'b0; #0.5 clk = 1'b1; end
  #10 $finish;
end

always @ (posedge clk) begin
   D_xmem_q   <= D_xmem;
   CEN_xmem_q <= CEN_xmem;
   WEN_xmem_q <= WEN_xmem;
   A_pmem_q   <= A_pmem;
   CEN_pmem_q <= CEN_pmem;
   WEN_pmem_q <= WEN_pmem;
   A_xmem_q   <= A_xmem;
   ofifo_rd_q <= ofifo_rd;
   acc_q      <= acc;
   l0_rd_q    <= l0_rd;
   l0_wr_q    <= l0_wr;
   execute_q  <= execute;
   load_q     <= load;
   mode_q     <= mode;
   shift_q    <= shift;
   save_q     <= save_y0;
   loady0_q   <= load_y0;
   relu_q     <= relu_en;
end

endmodule
