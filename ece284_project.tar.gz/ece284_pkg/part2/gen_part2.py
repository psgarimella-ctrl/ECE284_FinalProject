# gen_part2.py : data files + golden outputs for Part 2 (differential video-frame processing)
# Writes (all in the current folder):
#   weight_itile0_otile0_kij0..8.txt   8 lines x 32b   (same format as Part 1)
#   act_x0_high.txt, act_x0_low.txt    36 lines x 32b  (unsigned 4-bit nibbles of X0)
#   act_dx1.txt .. act_dx3.txt         36 lines x 32b  (signed 4-bit clipped deltas)
#   acc_address.txt                    16 x 9 pmem addresses (pass-0 region)
#   out_y0.txt .. out_y3.txt           16 lines x 192b (8 oc x 24-bit, oc7..oc0), NO ReLU
# and prints the accuracy analysis for the report.
import numpy as np

IC, OC, K, H, OH = 8, 8, 3, 6, 4      # 8x8 layer, 3x3 kernel, 6x6 padded input, 4x4 output
ACC_BW = 24

# ------------------------------------------------------------------
# 1) WEIGHTS: replace with your trained squeezed layer (w_int, values -8..7, shape (8,8,3,3))
# ------------------------------------------------------------------
rng = np.random.default_rng(1)
w = rng.integers(-8, 8, size=(OC, IC, K, K))

# ------------------------------------------------------------------
# 2) FRAMES: replace with the provided frames X0..X3 (8-bit, shape (8, 6, 6) each, zero-padded)
#    Below: synthetic "video" = X0 plus small motion noise, with a few big changes.
# ------------------------------------------------------------------
X0 = np.zeros((IC, H, H), dtype=int)
X0[:, 1:5, 1:5] = rng.integers(0, 256, size=(IC, 4, 4))
frames = [X0]
for f in range(1, 4):
    noise = rng.integers(-6, 7, size=(IC, 4, 4))
    big = rng.random((IC, 4, 4)) < 0.05                 # ~5% pixels change a lot
    noise[big] = rng.integers(-60, 61, size=big.sum())
    Xf = X0.copy()
    Xf[:, 1:5, 1:5] = np.clip(X0[:, 1:5, 1:5] + noise, 0, 255)
    frames.append(Xf)

# ------------------------------------------------------------------
def b(v, n): return format(int(v) & ((1 << n) - 1), f'0{n}b')

def conv(wt, x):                       # raw conv output (no ReLU), shape (OC, 4, 4)
    y = np.zeros((OC, OH, OH), dtype=np.int64)
    for oi in range(OH):
        for oj in range(OH):
            y[:, oi, oj] = np.einsum('oikl,ikl->o', wt, x[:, oi:oi+K, oj:oj+K])
    return y

def write_act(name, a):                # a: (IC, 6, 6) values already in 4-bit range
    with open(name, 'w') as fh:
        fh.write('#time0row7[msb-lsb]\n#time1row7[msb-lsb]\n#................\n')
        for nij in range(H*H):
            fh.write(''.join(b(a[ic, nij//H, nij%H], 4) for ic in reversed(range(IC))) + '\n')

def write_out(name, y):                # y: (OC, 4, 4)
    with open(name, 'w') as fh:
        fh.write('#onij0[oc7...oc0]\n#onij1[oc7...oc0]\n#................\n')
        for oi in range(OH):
            for oj in range(OH):
                fh.write(''.join(b(y[oc, oi, oj], ACC_BW) for oc in reversed(range(OC))) + '\n')

# weights
for kij in range(K*K):
    ki, kj = divmod(kij, K)
    with open(f'weight_itile0_otile0_kij{kij}.txt', 'w') as fh:
        fh.write('#col0row7[msb-lsb]\n#col1row7[msb-lsb]\n#................\n')
        for oc in range(OC):
            fh.write(''.join(b(w[oc, ic, ki, kj], 4) for ic in reversed(range(IC))) + '\n')

# activations: X0 nibbles + clipped deltas
x0_high, x0_low = X0 >> 4, X0 & 15
write_act('act_x0_high.txt', x0_high)
write_act('act_x0_low.txt',  x0_low)
deltas, sat = [], []
for f in range(1, 4):
    d = frames[f] - X0
    dc = np.clip(d, -8, 7)
    deltas.append(dc)
    sat.append(np.mean(d[:, 1:5, 1:5] != dc[:, 1:5, 1:5]))
    write_act(f'act_dx{f}.txt', dc)

# accumulation addresses (pass 0 region): kij*36 + nij'
with open('acc_address.txt', 'w') as fh:
    fh.write('#onij0kij0\n#onij0kij1\n#..........\n')
    for oi in range(OH):
        for oj in range(OH):
            for kij in range(K*K):
                ki, kj = divmod(kij, K)
                fh.write(b(kij*H*H + (oi+ki)*H + (oj+kj), 11) + '\n')

# golden outputs
Y0 = 16*conv(w, x0_high) + conv(w, x0_low)
assert np.array_equal(Y0, conv(w, X0)), "nibble split must be exact"
write_out('out_y0.txt', Y0)
print('Y0 range: %d .. %d  (needs %d-bit signed)' % (Y0.min(), Y0.max(),
      int(np.ceil(np.log2(max(abs(Y0.min()), Y0.max()) + 1))) + 1))
print('\nframe  sat%    max|err|   MSE        SQNR(dB)')
for f in range(1, 4):
    Yr = Y0 + conv(w, deltas[f-1])      # what the hardware computes
    Yt = conv(w, frames[f])             # exact answer
    write_out(f'out_y{f}.txt', Yr)
    err = Yr - Yt
    mse = np.mean(err.astype(float)**2)
    sqnr = 10*np.log10(np.mean(Yt.astype(float)**2) / mse) if mse > 0 else float('inf')
    print('Y%d    %5.1f%%  %8d   %10.1f   %6.1f' % (f, 100*sat[f-1], np.abs(err).max(), mse, sqnr))
print('\nPasses per kij: conventional 8 (4 frames x 2 nibbles), differential 5  -> 1.6x fewer')
